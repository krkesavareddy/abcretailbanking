package com.hcl.retailbank.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.retailbank.pojo.Response;
import com.hcl.retailbank.service.RetailbankService;

@RestController
@RequestMapping("/retailmapping")
public class RetailController {
	
	@Autowired
	RetailbankService retailBankService;
	
	@PostMapping("/customerLogin")
	public Response customerLogin(@RequestParam("id") int id) {
		if(retailBankService.validateUser(id)) {
			return new Response("Welcome",Boolean.TRUE);
		}
		return new Response("Please check the user id", Boolean.FALSE);
	}
	
}