package com.hcl.retailbank.service;

import org.springframework.stereotype.Service;

@Service
public interface RetailbankService {
	
	boolean validateUser(long id);
	
}