package com.hcl.retailbank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.retailbank.repository.CustomerLoginRepository;

@Service
public class RetailbankServiceImpl implements RetailbankService {

	@Autowired
	CustomerLoginRepository customerLoginRepo;
	
	@Override
	public boolean validateUser(long id) {
		boolean userExists = customerLoginRepo.existsById((int) id);
		return userExists;
	}

}