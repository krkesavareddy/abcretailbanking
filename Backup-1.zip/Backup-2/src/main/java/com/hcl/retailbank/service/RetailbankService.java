package com.hcl.retailbank.service;

import org.springframework.stereotype.Service;

import com.hcl.retailbank.entity.CustomerCreation;

@Service
public interface RetailbankService {
	
	boolean validateUser(long id);

	void fetchAccountSummary(CustomerCreation customerCreation);
	
}