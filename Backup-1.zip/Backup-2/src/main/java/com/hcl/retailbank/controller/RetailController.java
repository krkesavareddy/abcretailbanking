package com.hcl.retailbank.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.retailbank.entity.CustomerCreation;
import com.hcl.retailbank.pojo.Response;
import com.hcl.retailbank.service.RetailbankService;

@RestController
@RequestMapping("/retailanking")
public class RetailController {
	
	@Autowired
	RetailbankService retailBankService;
	
	@PostMapping("/customerLogin")
	public Response customerLogin(@RequestParam("id") int id) {
		if(retailBankService.validateUser(id)) {
			return new Response("Welcome",Boolean.TRUE);
		}
		return new Response("Please check the user id", Boolean.FALSE);
	}
	
	@GetMapping("/accountSummary")
	public Response getAccountSummary() {
		CustomerCreation customerCreation=new CustomerCreation();
		customerCreation.getCustomerId();
		customerCreation.getCustomerName();
		customerCreation.getBalance();
		retailBankService.fetchAccountSummary(customerCreation);
		return new Response("Custom Account summary",Boolean.TRUE);
	}
	
}